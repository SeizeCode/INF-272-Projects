window.addEventListener("load", function () {
  const computerChoiceDisplay = document.getElementById('computer-choice');
  const userChoiceDisplay = document.getElementById('user-choice');
  const resultDisplay = document.getElementById('result');
  const possibleChoices = document.querySelectorAll(".game");
  let userChoice;
  let computerChoice;
  var result;
  
  
var clickrock=document.getElementById("rock").innerHTML;//when user clicks "rock"
var clickpaper=document.getElementById("paper").innerHTML;//when user click "paper"
var clickscissors=document.getElementById("scissors").innerHTML//when user clicks "scissors"

//Add event listener to buttons 
possibleChoices.forEach(el=>el.addEventListener("click",event=>{
 userChoiceDisplay.innerHTML=el.innerHTML;
 generateComputerChoice();
 getResult();
}));
  //code to generate and display computer choice 

  //function to randomise array
  var random=[];
    random.push(clickrock,clickpaper,clickscissors);
  function randomise(val)
  {
    val.sort(()=>Math.random()-0.5);
  }
  var i=0;//increament
  function generateComputerChoice() {
    randomise(random);//call function ("random") and use it for the array
    computerChoiceDisplay.innerHTML = random[i];//display the current index of thee array
  }

  //function to compare user choice and computer choice and generate and display result
  function getResult() {
    //if user picks same as computer
    
    if(userChoiceDisplay.innerHTML==computerChoiceDisplay.innerHTML){
     document.getElementById("result").innerHTML="It's a draw";
     document.getElementById("result").style.color="Orange";
    }
    //if user picks rock and computer "paper"
    else if(userChoiceDisplay.innerHTML=="rock" && computerChoiceDisplay.innerHTML=="paper" )
    {
      document.getElementById("result").innerHTML="You Lose,try again";
      document.getElementById("result").style.color="red";
    }
     //if user pics rock and computer scissors
     else if(userChoiceDisplay.innerHTML=="rock" && computerChoiceDisplay.innerHTML=="scissors" )
     {
       document.getElementById("result").innerHTML="Well Done";
       document.getElementById("result").style.color="green";
     }

    //if user picks scissors & computer picks paper
    else if(userChoiceDisplay.innerHTML=="scissors" && computerChoiceDisplay.innerHTML=="paper" )
    {
      document.getElementById("result").innerHTML="Well Done";
      document.getElementById("result").style.color="green";
    }
     //if user picks scissors & computer rock
     else if(userChoiceDisplay.innerHTML=="scissors" && computerChoiceDisplay.innerHTML=="rock" )
     {
      document.getElementById("result").innerHTML="You Lose,try again";
      document.getElementById("result").style.color="red";
     }
    //if user picks paper
    else if(userChoiceDisplay.innerHTML=="paper" && computerChoiceDisplay.innerHTML=="scissors")
    {
      document.getElementById("result").innerHTML="You Lose,try again";
      document.getElementById("result").style.color="red";
    }
    //if user picks paper computer picks rock
    else if(userChoiceDisplay.innerHTML=="paper" && computerChoiceDisplay.innerHTML=="rock")
    {
      document.getElementById("result").innerHTML="You Lose,try again";
      document.getElementById("result").style.color="red";
    }
   
  }



    //function to create the objects and push it to array (optional).
    
    //var random=[clickrock,clickpaper,clickscissors];
    function buildObject() {
      
    }
var j=0;
    //function to build the string to be displayed
    function GameHistory() {
      //create array to store all the reuslts
      var allresults=[];
     allresults.push(result);//store in an arry created
     //alert(allresults[j]);
    }
    
    
    //displaying the summary of games data
    function Summary() {
      
      GameHistory();//call the function
    }

      //calling function to display games history when button is clicked
    this.document.getElementById("summary").addEventListener("click",Summary);
    //clear results and choices
    document.getElementById("clear").addEventListener("click",function(){
    document.getElementById("computer-choice").innerHTML="";
    document.getElementById("user-choice").innerHTML="";
    document.getElementById("result").innerHTML="";
   
});  
});



