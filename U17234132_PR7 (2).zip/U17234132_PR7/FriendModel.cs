﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace u17234132_PR7._1.Models
{
    public class FriendModel
    {
        //Add a Model called 'FriendModel'

        //Name string
        [DisplayName("Name")]
        public string Name { get; set; }
        //Surname string

        [DisplayName("Surname")]
        public string Surname { get; set; }
        //Email string

        [DisplayName("E-mail")]
        public string Email { get; set; }
        //Date

        [DisplayName("Birthday date")]
        [DataType(DataType.Date)]   
        public DateTime Birthday { get; set; }

    }
}