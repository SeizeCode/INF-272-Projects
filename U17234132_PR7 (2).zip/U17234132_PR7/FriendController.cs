﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel;
using System.Data;
using u17234132_PR7._1.Models;


namespace u17234132_PR7._2.Controllers
{
    public class FriendController : Controller
    {
        FriendModel FriendModel = new FriendModel();
        // GET: Friend
        public ActionResult Index()
        {
            List<FriendModel> Friends = new List<FriendModel>()
            {
                new FriendModel()
                {
                    Name="Nkosinathi",
                    Surname="Msiza",
                    Birthday=new DateTime(1998,10,05),
                    Email="seizemsiza@gmail.com",
                },
                new FriendModel()
                {
                    Name="Bongani",
                    Surname="Msiza",
                    Birthday=new DateTime(1994,03,23),
                    Email="belovedmsiza@gamil.com",
                },
                new FriendModel()
                {
                    Name="Vusin",
                    Surname="Mashabela",
                    Birthday=new DateTime(1994,03,23),
                    Email="johanessmashabela96@gmail.com",
                },
                new FriendModel()
                {
                    Name="Sibongile",
                    Surname="Mashabela",
                    Birthday=new DateTime(1969,03,14),
                    Email="sibongilemsiza@gmail.com",
                }
            };
            return View(Friends);
        }

    }
}
